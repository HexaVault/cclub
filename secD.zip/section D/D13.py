# D13: Multi-parameter Functions VII

def reducer(array, function, initalValue = 0):
  value = function(initalValue, array[0])
  for item in array[1:]:
    value = function(value, item)
  return value

# Above is a reducer function, which takes in a list and reducer function, and returns an output.
# Below are a couple examples of reducers:

def add(a, b): return a + b
def prod(a, b): return a + b

# By finding (or making) a function that takes the biggest value between a and b:
# Find the smallest and largest value of T.
# For your sake, T is defined under D13.info.txt

with open("D13.info.txt") as file:
  string = file.read()

array = string.split(", ")

i = 0
for value in array:
  array[i] = int(array[i])
  i += 1

# Start writing code below this comment


chosenFunction = add # Change "add" here to the name of your function
# Stop writing code above this comment

print(reducer(array, chosenFunction, 0))