from math import pi 
# D48: Named Parameters IV

# In D45 we stated that they must be in the form a=b. This is not quite true.
# We can actually drop the =b entirely, in order to make REQUIRED keyword arguments.
# This is generally unfavourable compared to just making them positional, but might be useful
# especially in cases where it is not clear what each value means without looking at the function definition.

# Make a function that calculates the area of a shape.
# Allow the inputs to be "square", "triangle" and "circle"
# Area of square = 4r^2
# Area of circle = pi * r^2
# Area of triangle = 4r^2/sqrt(3)

# Make the shape parameter a required keyword, and the radius a required positional