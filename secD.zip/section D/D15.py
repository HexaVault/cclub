# D15: Multi-parameter Functions IX

# When a character moves, you generally dont want the movement to be snappy.
# This means instead of just snapping to the new velocity, you slowly accelerate to that speed.
# Some more complex people may also want to introduce jerk proportional to velocity.
# This means that acceleration is equal to startAccel - currentVelo/maxVelo in the correct direction.

# Write a function that takes in velocity and acceleration and returns the speed in the next "frame"
# Below is some info:

# The maximum velocity of the character is 15 units per second, in either direction
# Velocity can be input as positive or negative, same with acceleration
# The character should accelerate at 0.45 units per second when at 0 velocity.