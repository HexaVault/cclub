# D12: Multi-parameter Functions VI

# We may also find it useful to use multi-parameter functions.
# Take in an input from the user, which we will call x.
# Find, to 3 decimal points, the value of y such that function(x, y) is equal to 1

# If no solution exists, state so.

def function(x, y):
  return 4 * x ** (3 - y ** 0.25) + 17 * (y - x ** 2.23)