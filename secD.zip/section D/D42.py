# D42: Dunders X

# There is one last brief set of dunders I want to run over.
# These are the dunders used by the math module.
# Mainly abs, round, trunc, floor and ceil
# Floor and Ceil round down and up
# Round, well, rounds
# abs takes the Absolute of a value. If you don't understand this, just take it as -x -> x, and x -> x
# trunc truncates the value. So 4.99999 would be 4, but 5 would 5, and so would 5.923 or 5.2234.
# trunc does have the weird behavior of -99.23 -> -99, since we are removing decimal (but not rounding down)

# Make a number class that stores 2 numbers.
# Addition and subtract should work on each pair seperately (so (2, 3) + (3, 3) = (5, 6))
# Multiplication should be cross (so (2, 3) * (4, 2) = (2 * 2, 3 * 4) = (4, 12))
# Additionally, add functionality for all these dunders listed.
# These dunders can all independently apply on each number (so round (4.8, 3.2) = (5, 3))