# D16: Multi-parameter Functions X

# Newton-Raphson method lets us quickly approximate the roots to a polynomial.
# It works by taking the derivative of f(x), and doing x = x - f(x)/f'(x)

# Make a function that takes in an input x as well as a cubic (ax^3 + bx^2 + cx + d) and performs newtons method
# The cubic will be input as 5 seperate inputs
# The derivative of a cubic is 3ax^2 + 2bx + c