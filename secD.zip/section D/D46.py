# D46: Named Parameters II

# Some builtins already have their own named parameters.
# Print an item, but override the end and flush arguments to be " <end>" and True, respectively