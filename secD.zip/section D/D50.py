# D50: *args II

# We can also do this with keyword arguments, by doing **kwargs (instead of *args)
# Functionally, they work almost the same, with the only difference being
# that one is keyword and returns dict, while one is positional and returns tuple.

# Make a function that takes in an infinite number of named parameters.
# Iterate through these using for a, b in c.items()
# and print each pair to the console.