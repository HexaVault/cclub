# D22: Classes I

# Functions are not the only way to modularise your code
# As an Object Oriented Language (OOL, also called OOP), python uses classes.
# This allows us to use multiple benefits, such as polymorphism (multiple things act the same but are different)
# Below is an example of a class

class MyBasicClass:
  value1 = 4
  value2 = False

# Write a class, with an appropriate name, that stores:
# Age
# Employment
# Birth date (as tuple)

# Make sure all internal variables also have an appropriate name