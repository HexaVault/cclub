# D54: Decorators III

# Let's put everything we have used together.
# Below is the reciever class from D40

class Reciever:
  recRecieverList = []

  def __init__(self):
    self.freq = []
    self.bcFreq = 0
    self.lrm = None
    self.lbm = None
    self.isActive = False
    self.storedData = []
    Reciever.recRecieverList.append(self)
  
  def setReciever(self, freq):
    if type(freq) == list:
      for item in freq:
        self.freq.append(item)
      return
    self.freq.append(freq)
  
  # async is something you will go through in section E
  async def broadcast(self, data, freq = -1):
    if not self.isActive: return
    if freq == -1: freq = self.bcFreq
    self.lbm = data
    for value in Reciever.recRecieverList:
      if value.isActive and freq in value.freq:
        value.lrm = data
  
  def toggle(self):
    self.isActive = not self.isActive
  
  def prepRemoval(self):
    Reciever.recRecieverList.pop(Reciever.recRecieverList.index(self))

# Replace prepRemoval to the del dunder
# Set up getters and setters for internal data.