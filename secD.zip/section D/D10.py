from math import cos, sin, pi

# D10: Multi-parameter Functions IV

# We can calculate how far an object launched is going to go, if we know its speed and angle.
# We can do this by first splitting the object into upwards (speed * sin(angle)) and forwards (speed * cos(angle))
# We can then do 2 * upwards/9.8 to find how long it will take to hit the floor
# Finally, we multiply this value by the forwards speed to get the distance.

# Make a function that takes in a speed and angle (theta) and returns the distance travelled.
# You will need to convert the angle by multiplying it by pi/180
# You may assume the speed is above 0, and the angle is in the range 0 < x < 90.