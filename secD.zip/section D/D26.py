# D26: Classes V

# Class functions can also be accessed using dot notation, like variables.

# Create a class function that adds all the items in a list together
# The input should be called "self", and the list is in "self.data"
# Then, create a new instance of myClass, and add 6 things to x.data
# Run your class function on your instance, via x.function(name)

class myClass:
  def __init__(self):
    self.data = []