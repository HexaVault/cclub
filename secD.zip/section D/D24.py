# D24: Classes III

# Although storing data like this can be quite nice, it does not provide an immediately
# noticable benefit over using something simpler, like an array, dictionary or even just a variable.
# We can fix this by using polymorphism.

# A class is provided below for convenience. The init class will be explained in a later file.

class Person:
  def __init__(self):
    self.age = 0
    self.job = "None"
    self.birthDate = (1, 1, 2000) # DMY

# We can now define multiple variables to this class, like the example below
Person1 = Person()
Person1.age = 22
Person1.job = "Teacher"
# Note: Written 25/02/2026, may be innaccurate when you are using it
Person1.birthDate = (7, 2, 2004)

# We can then do this again with a second Person:

Person2 = Person()
Person2.age = 17
Person2.job = "None"
# Note: Written 25/02/2026, may be innaccurate when you are using it
Person2.birthDate = (2, 6, 2008)

# You will now see that Person1.age and Person2.age are different.
# This is called Polymorphism.

# Create 3 more people, named Person3-Person5 respectively, and take inputs from them.
# Calculate the average age (add them together and devide by 5)