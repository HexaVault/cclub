# D45: Named Parameters I

# In some cases, we might not want every parameter.
# So far, we would put these at the end, and hope we only have one optional parameter.
# But what if we have multiple?

# This is where named parameters come in.
# We can give each parameter a name, and then the user can use name=data to define it.
# In order to do this, we add a positional "paramater" named * (not as string).
# All parameters after the * must be in the form name=data and can only be called via keyword.

# Make a function called log, which takes in one positional argument and a keyword argument called "severity"
# severity should have a default value of 0

# (Replace "Info" in the below statements with whatever the user inputs to the function)
# If severity is 0, the log should print "Log: Info"
# If severity is 1, the log should print "Warn: Info"
# If severity is 2, the log should print "Error: Info" and raise an error: raise ValueError("An error was raised")