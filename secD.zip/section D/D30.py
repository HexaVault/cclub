from math import pi
# D30: Inheritance I

# We can also do something called inhertiance with classes.
# This means that classA inherits all the data from classB.
# Below is a class called Shape

class Shape:
  def __init__(self):
    self.rad = 0
  
  def area(self):
    pass

  def circ(self):
    pass

# We can now make a class that inherits this, like seen below:

class Square(Shape):
  def area(self):
    return 4 * self.rad ** 2
  
  def circ(self):
    return 8 * self.rad

# Here, we have two classes. The top class can be referred to as the Parent class, and the lower one the Child class.
# We can see in the child class, we define the area and circ as functions, so they will run as normal.
# However, since we dont define the __init__ function, it is inherited from the Parent class, Shape.

# Make a circle class that inherits from Shape.
# The area of a circle is pi * r^2
# The circumference of a circle is 2pi * r