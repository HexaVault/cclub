# D27: Classes VI

# The self parameter is often used in classes.
# It is the first parameter of a function, and generally denotes the instance the function is run on
# For example, if you have a variable myVar, and you run the function myVar.myFunc(),
# then the self parameter will be equal to myVar.
# Note we can always call class functions with class.function(para) rather than instance.function()

# Change the init class to add 3 bits of data to the instance:
# lastOpened (as a number)
# canRead (as a bool)
# canWrite (as a bool)
# Add a function called canAppend that only returns true if the user canRead and canWrite
# Add a function called isRecent that only returns true if lastOpened < 16800

class fileHandler:
  def __init__(self):
    pass