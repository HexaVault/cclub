# D53: Decorators II

# We can also create create and use our own decorators.
# For this to work, the decorator must take in a function as an input,
# and must return a function.

# Make a decorator that returns text, but only in lowercase (.lower)