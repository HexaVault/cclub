# D36: Dunders IV

# There are also comparison dunders.
# These are as listed:

# __eq__ ==
# __ne__ !=
# __lt__ <
# __le__ <=
# __ge__ >=
# __gt__ >

# Make a Person class that stores Age and Job
# Make the number comparison classes (gt, lt, ge, le) compare ages
# Make eq return whether both people have the same job