from math import pi
# D1: Functions I

# We can use functions to modularise and reuse code.
# Rather than copypasting a piece of code over and over, we use a function.
# We can even give an input to a function to change its code

# Functions follow the below format:
def myFunction(myInput):
  return "myValue"

# Write a function called "circleArea" that calculates the area of a circle.
# Area of a circle = pi * area * area