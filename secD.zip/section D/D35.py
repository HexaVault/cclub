# D35: Dunders III

# However, we may want use i operators, such at += or *=
# These are similar to r operators, where we add an "i" before the dunder text

# Below is a shape class

class Shape:
  def __init__(self):
    self.height = 0
    self.length = 0
  
  def area(self):
    pass

  def circ(self):
    pass

# You can then implement a rectangle class below.
# In this class, implement an imul function - This requires a self and another parameter
# If the input is a number, multiply height and length by sqrt(x)
# If the input is another rectangle, multiply the heights and lengths together.
# Remember to return the class after you modify it.