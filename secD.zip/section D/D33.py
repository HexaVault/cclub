# D33: Dunders I

# Double UNDERscore variableS, shorted to Dunders for short, are specialised functions for classes.
# They allow us to modify special properties of classes.
# We will first look at the one you have already come across, called __init__.

# __init__ (aka init) is a function that defines what should occur at initation.
# This function is run on the variable X when you do X = myClass(para), with X as the first parameter.
# It allows us to put data inside of self for later use.

# Create a class with an init function, and create a instance variable (default of 0).
# Create a function that returns whether this instance variable is greater than 10