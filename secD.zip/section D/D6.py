# D6: Using Functions III

def median(inp):
  if len(inp) % 2 == 0:
    return (inp[len(inp) // 2] + inp[len(inp) // 2 - 1]) / 2
  return inp[len(inp) // 2]

# The above function finds the median (middle number) of a list.
# Write a piece of code that finds all solutions to:
# median([5, 19, a, b, 27, 35]) = 23
# Assuming a and b are integers.