from math import pi
# D25: Classes IV

# Classes dont just have to have variables
# We can also define class functions

# Create a class called Area, with 3 functions
# One function should calculate the area of a square (l^2)
# One function should calculate the area of a circle (pi * r^2)
# One function should calculate the area of a cube (6 * l^2)