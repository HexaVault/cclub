# D17: Redefinition I

# We can quickly define other things as functions without rewriting it
# For example, if we have a function myFunc and we want to be called myNewFunc
# we can do myNewFunc = myFunc

# This makes myNewFunc copy the function.

def ca(v, a, m, dt):
  return a * (dt - v * dt/m)

# Give the above function a more descriptive name
# You may only write below this comment
  