# D44: Super II

# We can also use this to create basic wrappers around functions.
# For example, we may want to log when a specific dunder is used.

# Make a subclass of string (str)
# Write a wrapper around string that prints whenever add, radd or iadd is called,
# before passing it off appropriately to the super (parent) function definition.