# D40: Dunders VIII

# There are alot of dunders that we need to cover, but dont deserve their own file.
# Below is a class to save time:

class Reciever:
  recRecieverList = []

  def __init__(self):
    self.freq = []
    self.bcFreq = 0
    self.lrm = None
    self.lbm = None
    self.isActive = False
    self.storedData = []
    Reciever.recRecieverList.append(self)
  
  def setReciever(self, freq):
    if type(freq) == list:
      for item in freq:
        self.freq.append(item)
      return
    self.freq.append(freq)
  
  # async is something you will go through in section E
  async def broadcast(self, data, freq = -1):
    if not self.isActive: return
    if freq == -1: freq = self.bcFreq
    self.lbm = data
    for value in Reciever.recRecieverList:
      if value.isActive and freq in value.freq:
        value.lrm = data
  
  def toggle(self):
    self.isActive = not self.isActive
  
  def prepRemoval(self):
    Reciever.recRecieverList.pop(Reciever.recRecieverList.index(self))

# Make a child class of Reciever. You can name it whatever, or if you can't think of a name, call it RecieverSC
# Override the below functions with the appropriate dunders. Search then up if you are lost, or use this link:
# https://www.pythonmorsels.com/every-dunder-method/
# make len(x) return the length of stored data
# make str(x) return the last recieved message
# make bool(x) return whether the Reciever is "active"
# Make int(x) or float(x) return the broadcasting frequency
# Lastly, make iterating through the class go through storedData
# Do not modify any exiting protocols.