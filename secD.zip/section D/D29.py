# D29: Classes VIII

# Although dot notation doesnt allow us to, we can actually use class functions with other classes
# This only requires that the instance variables expected exist in the class we input
# Below are two classes. Make a function in myClassA, such that myClassA.function(class) is true, even if we change the data
# But make the function such that myClassA.function(class from myClassB) returns false, even if we change the data

class myClassA:
  def __init__(self):
    self.data1 = False
    self.data2 = "Test"
    self.data3 = [1, 4, 20]

class myClassB:
  def __init__(self):
    self.data1 = False
    self.data3 = [1, 4, 20]
