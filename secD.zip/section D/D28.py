# D28: Classes VII

# We can actually mix and match all these things together.

# Make a class with the following:
# Two class variables, labelled allowOverwrite (bool / False) and maxFileSize (int / 6500000)
# An __init__ function (we will explain this in D33) that takes a self parameter
# This init function should define the instance values for canWr, canRead, canExec, lastOpened, fileSize and Owner
# A canExecute function, which requires read and execute permissions
# A canAppend function, which requires read and write permissions
# A canWrite function, which requires allowOverwrite and write permissions
# A isTooLarge function which also takes an additional parameter, and returns whether fileSize + parameter > maxFileSize
# A canDelete function which also takes an additional parameter, and requires either read + write + overwrite, or parameter == Owner