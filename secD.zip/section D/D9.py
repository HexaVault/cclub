# D9: Multi-parameter Functions III

# We can also take in functions and return outputs.
# Write a function that takes in a function and number,
# and finds the largest integer x such that function(x) < number
# You may assume that the function is bounded in the range 0-50 inclusive.