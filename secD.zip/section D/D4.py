# D4: Using Functions I

def sqr(t):
  return t ** 2

# The function above takes in an input and returns the square number.
# Create a piece of code that takes in an input, and converts it to a number.
# Then, using only the function above, find the biggest whole number where n ** 2 < x