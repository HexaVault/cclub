# D23: Classes II

# We can also access data from classes. There are generally two ways:
# We can use class["dataName"]
# Or we can use class.dataName
# This also allows us to modify data that is stored inside a class.

# Copy and Paste your code from D22.
# Ask the user for their age, employment and birth date (either with 3 inputs, or in 1)
# Store this information in your class
# You may not have input() inside your class definition