# D3: Functions III

# Create a function that returns the nth power of 2.
# Name the function nth2pow