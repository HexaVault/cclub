from math import pi
# D14: Multi-parameter Functions VIII

# Write a function that calculates the volume of:
# A tetrahedron
# A cylinder
# A sphere

# You may search up these formulas