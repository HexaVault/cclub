# D49: *args I

# In some cases, there may be an unlimited number of positional parameters that we want to accept.
# To accept these, we can use *args (args can be any variable name).
# *args allows an infinite number of inputs, and can be treated as inputting a tuple.

# Make a log function that takes in an infinite number of inputs.
# Print each input on an independant line.