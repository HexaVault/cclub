# D58: Recursion I

# We can also use functions to make loops, via recursion.
# This can be done quite easily, just by calling the function inside of itself.

def mp(minimum, maximum):
  return (minimum + maximum) // 2
  
def bsearch(list, val):
  minPos = 0
  maxPos = len(list) - 1
  mid = mp(minPos, maxPos)
  if mid < val:
    minPos = mid
  else:
    maxPos = mid
  if minPos == maxPos: return minPos
  list = list[minPos:maxPos]
  # Add recursion here to make this function loop till it finds the exact values
