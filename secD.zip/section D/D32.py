# D32: Inheritance III

# We can even stack inheritance, also called multilevel inheritance.

# Below is the basic shape class from D30, with some modifications

class Shape:
  def __init__(self):
    self.height = 0
    self.length = 0
  
  def area(self):
    pass

  def circ(self):
    pass

# Write another class called Rectangle, where area = hl and circ = 2h + 2l
# Then, write a third class called Square.

# You may not change __init__
# You may assume the user will run the function fixHL before running the area or circ functions on Square.
# You may not modify any Parent functions in the Square class, but you may add more functions.