# D8: Multi-parameter Functions II

def easing(t):
  return 0.5 * (t ** 3 + t ** 1/3)

# In D7, you made a lerp function that uses a linear interpolation.
# Now, make an interpolation function that uses the above easing function.
# This means you take in the input of t, and run it through the above function, 
# before using that output to interpolate.