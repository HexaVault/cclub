# D39: Dunders VII

# The last operator to look at are the binary operators

# These are: and (&), or (|), xor (^) and not (~)
# There is also the rshift and lshift (>> and <<), but we wont really cover these.
# Even more additionally, there is the unary pos and neg (+x and -x) which we will again not really cover here.

# Create a "qword" class that stores 128 bits as 16 "bytes" (ints) in a tuple.
# This can be done by convert bits to numbers (00000000 is 0, 00000001 is 1, 00000010 is 2... 00010100 is 20, etc, etc)
# Handle the basic binary operators.

# AND: 0 & 0 = 0 / 0 & 1 = 0 / 1 & 0 = 0 / 1 & 1 = 1
# OR: 0 | 0 = 0  /  0 | 1 = 1  /  1 | 0 = 1  /  1 | 1 = 1
# XOR: 0 ^ 0 = 0 / 0 ^ 1 = 1 / 1 ^ 0 = 1 / 1 ^ 1 = 0
# NOT: ~0 = 1 / ~1 = 0