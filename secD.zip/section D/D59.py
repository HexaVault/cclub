# D59: Dunders XI

# The very last thing to look at (for now) are the get and set dunders, also called descriptors.
# This allows us to control assignment and retrieval in a more complex way.

# Take your code from D42 and copypaste it here.
# Add a new internal variable called storedValue to your class.
# Make a new class called desc, which does the below.
# Implement a get, which returns a tuple of the 2 stored values
# Implement a set, which takes in a tuple of 2 numbers, and sets the internal values to them.
# The get and set functions take 3 inputs each: self, instance and a thirdd value.
# Both functions should run on instance not self, but only the get cares about the third value.
# Lastly, once you have done this set your internal variable to be a instance of this desc class.