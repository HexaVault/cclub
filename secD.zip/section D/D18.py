# D18: Lambda I

# Lambda allows us to define small scale functions quickly.
# It takes the format shown below

exampleFunction = lambda input1: input1 * 3

# In the above function, it takes 1 parameter (input1) and returns 3 * input1.
# Note we do not need to use the keyword return, it is automatically assumed.

# Write a lambda function called add, that takes two inputs and adds them together.