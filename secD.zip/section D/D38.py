# D38: Dunders VI

# Hashing is one of the last builtins that we have yet to go through.
# Hash allows us to return a number that represents a thing
# Anything immutable (strings, arrays, numbers) are hashable by default.
# However, we can add a hash function to anything.

# Hashing is also useful as it allows us to compare values in a quick way.
# Additionally, we can use it to check whether data matches without knowing what that data.

# Create a number class that stores two parts (a "real" and "complex" part)
# Implement addition and subtract as normal (reals and complex dont interact)
# Implement a hash through a tuple of the real and complex