# D41: Dunders IX

# Now that we've gone through *pretty much* every dunder youll need,
# we can start creating larger classes to test on these uses.

# Create a "Money" class that allows you to add currencies together.
# The money class should work for GBP, EUR and USD
# You may assume that
# GBP:USD is 1:1.34
# GBP:EUR is 1:1.15
# EUR:USD is 1:1.16
# Allow adding currencies together, defaulting to the leftmost currencies.
# If adding a number to a currency, assume it to be the same currency.
# When printing as string, it should use $, € and £ proceeded by the number.
# Money should always be to 2 d.p. (so £3.20 not £3.2, and $0.85 not $.85 or whatever)
# Add a convert function to the class.