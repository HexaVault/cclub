# D20: Lambda III

# Below are 4 functions.
# Rewrite them using lambda.

def function(x, y):
  return 4 * x ** (3 - y ** 0.25) + 17 * (y - x ** 2.23)

def ca(v, a, m, dt):
  return a * (dt - v * dt/m)

def easing(t):
  return 0.5 * (t ** 3 + t ** 1/3)

# This function will need more than just copypaste
def calcNewTime(t, off):
  if t + off < 24 and t + off > 0:
    return t + off
  if (t + off > 24):
    return t + off - 24
  return t + off + 24