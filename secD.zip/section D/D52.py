# D52: Decorators I

# Decorators are one of the last things that are useful in python.
# Decorators allow us to modify the function of functions without changing the original function.
# To begin with, we will look at setters and getter decorators.

# Below is a basic class

class Person:
  def __init__(self, **data):
    self._name = data["name"]
    self._age = data["age"]
    self._job = data["job"]

# Normally, we would change say, the name, by doing self.name = X
# However, we may want to limit the inputs, i.e. to a string.
# In order to do this, we would do the following:

class example(Person):
  # Here we define name, as a property
  @property
  def name(self):
    return self._name
  
  # Here we define the setter for that property
  @name.setter
  def name(self, value):
    # Simply put, if it's a string set the name, else just print that something went wrong
    if isinstance(value, str):
      self._name = value
      return
    print("Attempted to set name, but was unsuccessful (was I not given a string?)")

# Make a subclass of person, and add appropriate limits to the inputs for name, age and job via decorators.