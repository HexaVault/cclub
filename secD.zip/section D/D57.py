# D57: Defintion Scope II

# (Note: These examples both are functions, but the same is true for functions)
# Global and Local scope also means that we cannot access glbal variables (i.e. to read data):

# Make a function that reads the global variable (num), and returns whether it is:
# A multiple of 2
# A whole number
# Bigger than 6
# Smaller than 15