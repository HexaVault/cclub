# D11: Multi-parameter Functions V

# One of the simplest functions that is used alot are sum.
# Write a sum function that takes in 2 lists, and returns the sum of both lists together.
# The sum of x can be thought of as adding all the values of x together