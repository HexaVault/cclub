# D55: Private Properties I

# So far, we have set up getters and setters, but the internal data is still public.
# This means although the user can do a.b = c, they could also directly set the internal
# value, skipping our decorators entirely.

# In order to prevent this, we want some data to be private, so it can only be accessed internally.
# To do this, we label the instance a.__b, rather than a.b.

# Modify the person class to have getters and setters for name, job and age.
# Make all the internal data private.

class Person:
  def __init__(self, **data):
    self._name = data["name"]
    self._age = data["age"]
    self._job = data["job"]

  @property
  def name(self):
    return self._name
  
  @name.setter
  def name(self, value):
    if isinstance(value, str):
      self._name = value
      return
    print("Attempted to set name, but was unsuccessful (was I not given a string?)")
