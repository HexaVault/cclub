# D5: Using Functions II

def cbx(x):
  return x ** 3

def sqx(x):
  return x ** 2

# Use the functions above to solve all the solutions of x^2 = x^3
# Assume x is an integer, and inside the range 0 to 15, excluding 0s