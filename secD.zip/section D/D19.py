# D19: Lambda II

# Lambda becomes more useful when we want to define a list of functions.
# Instead of writing def x... however many times, and then making an array of the functions
# we can simply write lambda x... in each position of the array.

# Make an array with 3 lambda functions.
# All lambda functions should take 1 input
# The first function should triple the input
# The second function should add 20 to the input
# The third function should subtract 5 from the input