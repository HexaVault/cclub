# D21: Lambda IV

# More complicated functions can be tricky to write and maintain in lambda.
# Rewrite this lambda function to be a normal function that is clear to read.

oldFunc = lambda i1, i2: i1 + i2 if i1 < i2 else i1 - i2 if i2 < i1 else i1 * i2 if i1 != 0 else 1