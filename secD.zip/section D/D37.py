# D37: Dunders V

# You might also want to add type conversion handling
# This also naturally exists in python, though dunders.

# Make a class called ioStream
# The class should have an internal array, and a "byte" (int) number to store "permissions".
# The class should have a canWrite, canRead and canArray function which return booleans
# The class should have an "append" function which adds values to the array
# You should also be able to add via class + "data" or class += "data", which goes through append
# Override the int such that int(class) = permission number
# Override the str such that str(class) = array (joined together)