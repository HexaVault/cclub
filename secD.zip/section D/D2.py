# D2: Functions II

# Create a function that calculates the mean of an array (list).
# The mean is equal to adding everything together (the sum) then deviding by the number of data points