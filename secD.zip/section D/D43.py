# D43: Super I

# In some cases, you may want to add to the functionality of the parent class, without replacing it
# For example, you may want +x to become +2x, but still work as normal.
# For this, we can use super()

# Below is a class that extends number.
# Override the number class such that a + b -> a + 2b
# You can do this by overriding the add, changing the values,
# and then inputting these into super.__add__

class extNumber(float):
  pass