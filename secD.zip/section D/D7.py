# D7: Multi-parameter Functions I

# The lerp functions linearly interpolates between 2 values a and b.
# At t = 0, the function returns a
# At t = 0.5, the function returns the midpoint of a and b
# At t = 1, the function returns b

# Write a function of name lerp that performs this function