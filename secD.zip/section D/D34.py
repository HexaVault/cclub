# D34: Dunders II

# However, init is not the only dunder that exists in python.
# Every math operator has a dunder. 
# Just to make it faster, below is a list of all of them.
# You may want to make a file that has these stored somewhere.

# __add__
# __divmod__
# __floordiv__
# __mod__
# __mul__
# __pow__
# __sub__
# __truediv__

# You can also place an r before them (i.e. __radd__).
# As all the operators work when you do myobj + other, the r variants work .
# when you do other + myobj, assuming that other does not define other + myobj already.

# Make a shape class that stores width and height.
# Make a child class called rectangle, that has an area function
# Make a multiplication dunder, such that class * b = area(class) * b