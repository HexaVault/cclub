# D31: Inheritance II

# Inheritance is very powerful as it allows to further reuse code.
# We can also define new function in the Child class that are absent in the Parent class.

class ioStream:
  def __init__(self):
    self.isOpen = False
    self.dataStream = []
  
  def toggleStream(self):
    self.isOpen ^= True

# Create a child class of ioStream class fileStream.
# Create a class initFile, which sets self.fileName to the given input
# Create a function closeStream, which closes the stream, regardless if open or closed.