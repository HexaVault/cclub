# D56: Definition Scope I

# When we use variables, we can define them in two places:
# Locally: This variable only exists within the function, but must be defined and used within the function
# Globally: This variable exists everywhere.

# We have primarily stuck to local variables so far, but you may want to use global variables.
# To use global variables (i.e. to update a counter), we must first tell python that we want to use the global variant
# By typing global varName (this is usually done at the top)

myCounter = 0

# Make a function that prints myCounter, and increments it by 1.