# A7: input I

# Another useful python function is input.
# This allows us to take input from the user.
# In order to take in input, we use a similar format to print:
input("Example: ")
# Note that there is a space after the colon (:), as otherwise the user would write
# just after Example:, and it would be come Example:hi rather than Example: hi

# Tahe an input from the user, asking "What is your name"