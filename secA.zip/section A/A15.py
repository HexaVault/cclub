# A15: Multiline I

# We can use \n in order to split strings into multiple lines.
# However, for long strings this can be tedious.
# Luckily, python has multiline strings which we can use, which does this for us.
# A multiline string is started with 3 quotation marks (""" or ''') and unlike normal strings
# you can go over multiple lines. In order to close it, you use the same 3 characters you used to open it.

# Below is a pararaph from wikipedia. Put it into a multiline string, and then print it.

# Mombasa's location on the Indian Ocean made it a historical trading centre, and it has been controlled by many countries because of its strategic location.
# Kenyan school history books place the founding of Mombasa as 900 AD.
# It must have already been a prosperous trading town in the 12th century, as the Arab geographer al-Idrisi mentions it in 1151.
# It was a part of the Kilwa Sultanate from approximately the early 14th century until the dissolution of the sultanate in 1513.
# The oldest stone mosque in Mombasa, Mnara, was built c. 1300. The Mandhry Mosque, built in 1570, has a minaret that contains a regionally specific ogee arch.
# The city later came under the occupation and control of the Omani Empire in the late 17th century.
