# A11: if I

# The if statement forms the basis of almost all programming.
# It allows us to run statements if a certain statement is true.
# For example, we could run a piece of code only if a variable is bigger than 8

# The if statements works by looking at whether a value is "Truthy" or "Falsy".
# What this means explictly isnt super important, but just know:
# 0, None, "", [], (), and False are all Falsy values
# Everything else can be considered to be Truthy

# If the expression in an if statement is Truhty, it will run the code inside the if statement.
# Below is an example of an if statement:

if 7 < 4:
  print("Hello World!")

# Here, since 7 is not less that 4, 7 < 4 will be evaluated as False, and so the if statement wont run.
# As with variables, we can also put functions like "input" into the if statement.

# Make an if statement thats prints "hi" if the user does not input a empty string.