# A17: if IV

# We can also combine statements.
# For example, we can use the "and" word to combine two statements together.

# Make a variable that takes in a number from the user
# Using only an if-else block, as well as "and":
# Print "|x| > 3" if x is bigger than 3, or less than 3
# Print "|x| <= 3" otherwise