# A3: print III

# Let's just make sure you understand the print function.
# Write a SINGLE print functions that prints the numbers 1 to 5 on their own lines.