# A9: Variables III

# The input function, however, does not store what the user puts in.
# To do that, we need to put it in a variable, like we would a number.

# Make a variable, and store the result of when you ask the user for their name (using input)