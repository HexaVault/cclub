# A16: if III

# Below is a piece of code that takes in a number from the user.
# Use an if-elif-else block to print:
# "Your number is negative" if the number is less than 0
# "Your number is positive" if the number is greater than 0
# "Your number is zero" otherwise

userNum = int(input("Choose a nunber: "))