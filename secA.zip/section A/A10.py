# A10: print V

# We can also stack the input function inside of print.
# This means instead of putting a string or variable name, we put in an input.

# Put an input function inside a print function
# Inside the input function, ask the user for their name