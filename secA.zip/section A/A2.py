# A2: print II

# We can also print multiple lines at once.
# In order to do this, we can use special characters.
# All special characters are in the form \? where ? is a character.
# This does mean in order to print \, you need to type \\

# Below is an example of using a special character
print("\tIndented Text")

# Write a print function that says Hello, World! on 2 seperate lines, by
# using the newline special character (\n)