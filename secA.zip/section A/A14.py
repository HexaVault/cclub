# A14: Variables IV

# We can now take in and store numbers (not strings) in variables.
# However, we might want to change these numbers, like adding 4.
# We can do this using operators.

# We will look more at operators in section B, but the ones you will want to use here are + and -.

myVar = 6
myVar = myVar
print(myVar) # Add or subtract from myVar so this is equal to 9
myVar = myVar
print(myVar) # Add or subtract from myVar so this is equal to 3
myVar = myVar
print(myVar) # Add or subtract from myVar so this is equal to 4
myVar = myVar
print(myVar) # Add or subtract from myVar so this is equal to 5