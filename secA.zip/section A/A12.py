# A12: if II

# If statements can also have else and elif parts.
# The structure is always if, followed by any number of elifs, followed by an optioned else at the end.
# This structre works by first trying the top if statement.
# If it succeeds, we skip the rest of the if statement and do not check any others (This is also called falling through)
# If it fails, we fall through to the next statement.
# If this statement is an elif, we repeat the above steps
# If this statement is an else, we run that code (this only occurs if all if/elif statements fail)

myVar = input("Are you older than 14? (y/n) ")

# Check whether myVar is a y or n using ==
# If it is a y, print "So am I"
# If it is an n, print "Well I am"