# A6: print IV

# On their own, variables are completely useless.
# However, we can start using them alongside other things.
# For example, we can print out the data in a variable.
pi = 3.1415926535897932

# When printing a variable, you do not wrap it in "quotation marks".
# Print out the variable pi, without writing out the number.