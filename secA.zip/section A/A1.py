# A1: print I

# Python is a coding language that we will be using to eventually create a game with pygame.
# However we need to look at the basics before we start on that.
# So to begin, we will start by looking at some of the basic builtins.

# print (in lowercase) is a function (We will go into more detail on what this is in section D)
# which allows us to write out things to the user (We call this writing to the console)
# Since print is a function, we need to wrap it like below:
print()

# If you run the program right now, you will notice that it prints an empty line.
# This is because we have not told it what to print.
# We can give it text (which we call a string) by "writing in quotation marks"
# If you remove the # from the below line and run it, you can see an example
#print("Example")

# Using this, write a print function that prints Hello World! to the terminal below.