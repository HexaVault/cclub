# A4: Variables I:

# We can use variables to store data.
# This is done using the form <variableName> = <data>
# <data> can be numbers (i.e. 1, 3, 17), strings (i.e. "Hello") or other types.
# Variable names have some rules:
# They cannot start with a number
# They must only contain alphanumeric characters (a-zA-Z0-9) or underscores (_)
# # This also means they cannot contain spaces
# They cannot be a reserved word (i.e. True, False, None, else, if, try, return, etc)
# They are case sensitive (var Var and vAR are all different)

# Giving it an appropriate name, store the first 8 digits of pi (3.1415926) in a variable.
# Since it is a number, you do not need to wrap it in "quotation marks"