# A5: Variables II

# We can also write over previously existing variables to change what they store.
myName = "undefined"
# Below, overwrite this variable such that it is equal to your name.