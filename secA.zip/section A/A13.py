# A13: int I

# The input builtin always returns a string.
# However, we might want it as a number.
# In order to change it to a number, we can use int()
# int() will convert a string to a number, but will throw an error if it can't.
# Unless we state otherwise, you can assume that int will always work.

# Below is an if statement.
# Between this comment and an if statement, ask the user their age.
# Convert the output into a number (remember, you can put input inside of int)
# and store it in a variable called userAge



if userAge < 18:
  print("You are not an adult")