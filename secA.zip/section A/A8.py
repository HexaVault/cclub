# A8: input II

# We can even just use input to wait for the user to hit enter.

# Write 2 print functions that write "Hello World!" on 2 lines.
# In between them, make an empty input statement