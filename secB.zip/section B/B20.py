# B20: Files I

# Python gives us a way to access files, through the open() builtin.
# By default, open will open the file in a read state, meaning we can only read it, not edit it.
# To open a file, we put it into the function (i.e. open("example.txt"))
# You do need to include the extension when reading. Unless we state otherwise, end with .txt for ease.

# You will then need to set a variable equal to that file.
# You can then read the file with variable.read(), or read each line (as an array) with variable.readlines()

# Open the file B20.info.txt
# Print the contents to the user