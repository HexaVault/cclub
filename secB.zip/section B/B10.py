# B10: Numbers II

# We done have to use x = x <op> a though.
# We can use ioperators, using the format x <op>= a

# For example, x += 4 is equal to x = x + 4

# A copy of B9's code is provided below.
# Repeat the task of replacing the pass statements, but use ioperators.

cVal = 0
print("Current value:", cVal)
uInp = input("Operator: ")
while uInp:
  if uInp == "+":
    pass
  elif uInp == "-":
    pass
  elif uInp == "*":
    pass
  elif uInp == "/":
    pass
  print("Current value:", cVal)
  uInp = input("Operator: ")
print("Final Value:", cVal)
