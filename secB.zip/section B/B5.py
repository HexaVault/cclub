# B5: Types II

# We can also check the type of a variable using the type builtin.
# Find out the type of the below variables

a = 7
b = 14.772
c = "test"
d = (1, 7, 123)
e = { a: 4 }