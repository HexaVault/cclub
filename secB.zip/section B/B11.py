# B11: Numbers III

# Python also provides a floordiv operator.
# Unlike regular division, this rounds down to the nearest whole number
# This would mean that 7 // 4 = 1, not 1.75

# Write code that prints if number // 9 is equal to 4
# This code should replace the pass statement in the below for loop

for num in range(1, 50):
  pass