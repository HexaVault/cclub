# B3: Flow control III

# Alongside this, we can also use the for loop
# The for loop will iternate (go through) each item of an object.
# This is generally characters for strings, and items for arrays.
# It follows the format: for <item> in <value>: where item is what you want to
# call the item you are on, and value is the item you want to loop through

# Take in an input from the user
# Loop through the input until it ends or you see the letter z
# For each loop, print the item you are on
# print("End")