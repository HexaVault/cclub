# B17: Strings IV

# We can also slice strings, to take parts.
# For example, we can do ""[:3] to take the first 3 characters.
# We can also do ""[4:] to take all characters after the 4th.
# We can even take individual characters, like ""[0] to take the first character
# Note computers count from 0, not 1, so in "abcd", [0] = a, [1] = b, [2] = c and [3] = d

# Take in an input from the user. You may assume it is more than 10 characters long.
# Print the string starting from character 4
# Print the string but stop it at character 7
# Print the characters 4-8 from the string (you can stack slices, like [1:7])