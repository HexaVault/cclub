# B15: Strings II

# We can multiply strings by numbers.
# For example, "-" * 4 = "----"
# This allows us to much more compactly print out repeated strings.

# Ask a question
# Take in an input
# Before, after and inbetween, make an appropriately long line of dashes (-)