# B16: Strings III

# We can also manipulate strings to UPPERCASE or lowercase by forece.
# We do this by adding .upper() and .lower() to the ends of strings.

# Take in an input from the user.
# Show them the string in all lower
# Show them the string in all upper
# Place a set of lines between each statement