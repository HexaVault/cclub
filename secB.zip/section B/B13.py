# B13: Numbers V

# The last operator to look at is the exponentiation operator, **.
# This operator can be thought of as repeated multiplication, if you have not used it before.
# This means x ** 2 is x squared, x ** 3 is x cubed, etc.
# We will likely use the a^b format in text, but note that ^ is xor and ** is exponentiation in python.

# Note: You may want to search up help for these, if you do not know how to:
# Print the answers to 4^3, sqrt(7), 1/cbrt(4) and 3^0