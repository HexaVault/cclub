# B8: Flow Control V

# Loops also contain a way to skip the rest of the current loop.
# This can be useful to not run code under certain criteria.
# The keyword is known as pass.

string = "This is a string that contains a decent quantity of the character s. You will use this string for the following code."

# Make a for loop that goes through each character of string
# If the character is "s" or " ", skip to the next character
# Else, print the current character