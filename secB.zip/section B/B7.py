# B7: Types III

# We can also use other functions, like the ones listed below, to convert between different types:
# bool(x) - Returns a boolean (True/False) depending on x
# int(x) - Returns an integer (whole number) depending on x
# float(x) - Returns a float (number) depending on x
# str(x) - Returns a string depending on x
# list(a, b, c...) - Returns a list (array) depending on inputs

# Make a list using list
# Make a string using str and a number
# Make an int and float through a string
# Show that 0 and [] are both falsy values