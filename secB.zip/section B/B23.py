# B23: range I

# The last thing to briefly look at is range().

# We can give in an input to range, such as range(1, 5), and it will return a tuple
# (you will learn what these are in section C). This lets us use it in for loops, for
# example in order to go through a piece of code with the numbers 1 to 5.

# Make a for loop that prints the numbers 1 to 10, using range()