# B9: Numbers I

# We can do alot more with numbers than just store them.
# Infact, we can use all the basic math operators:
# Add (via +)
# Subtract (via -)
# Multiply (via *)
# Divide (via /)

# Below is a for loop that takes in an input, and

cVal = 0
print("Current value:", cVal)
uInp = input("Operator: ")
while uInp:
  if uInp == "+":
    pass
  elif uInp == "-":
    pass
  elif uInp == "*":
    pass
  elif uInp == "/":
    pass
  print("Current value:", cVal)
  uInp = input("Operator: ")
print("Final Value:", cVal)

# Change the "pass" statements above to take in a input, convert it to a number, and apply that operator to cVal