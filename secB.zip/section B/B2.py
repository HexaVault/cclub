# B3: Flow control II

# The alternative way to exit a loop, is to use the break keyword
# This keyword will exit the current loop you are in

# Take in an input from the user
# Make a loop using "while True:"
# For each loop, print the input from the user and increment a counter by 1
# If the counter is greater than 8, exit
# print("End")

# Note: You will need to define your counter before you enter the while statement