# B19: Strings VI

# Lastly, we can take every x characters.
# For example, [::2] will take every second character, so "abcdefgh"[::2] = "aceg"
# We can also use negative numbers, which will reverse the string. 
# This means "abcde"[::-1] = "ebcda"

# Take in an input from the user
# Print out the following:
# 4th Character
# Last character
# Last 3 character
# First 4 characters
# Characters 6-8
# The string backwards
# The last 3 characters of the string, backwards
# Every second character
# Every second character, excluding the last 2