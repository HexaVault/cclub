# B1: Flow Control I

# Flow control refers to the ways we create jumps and loops in our code.
# You have already met one of these: the if statement.
# However, there are other statements to go through.

# The while loop is a loop that, while the condition given is truthy, will continue to repeat
# the code inside forever.

# For example, this means you count the number of objects in a list (there are better ways)

# The while loop is structured similarly to the if statement
counter = 0

# Take an input from the user
# If this input is not empty, add 1 to the counter
# Repeat steps 1 and 2 till the input is empty
# Print the counter
# You will do this using a while loop (think about truthy and falsy values if you are stuck)