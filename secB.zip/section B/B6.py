# B6: Flow Control IV

# We can merge these together to make sure that a variable is always of a certain type
# This is useful, especially if you dont know what a variable will be

var = 7

# Write an if statement to convert var to an int, if it is not an int already