# B22: Files III

# We can also the with statement, to compact our code.
# The with statement will let us temporarily define a variable.
# For example:

with 7 as test:
  print(test)

# Will print 7, however, if we try to use test outside the with loop, it will throw an error.
# For opening files, we can also combine modes, such as "r+a" to read the file and add to it.
# There is also "x" to create a file (error if it exists), as well as:
# "t" to open a file in text mode, such as a text file
# "b" to open a file in binary mode, such as pictures or audio.
# We will not be using these currently, however they may come up in sections C and E.

# Repeat B21's task, but use the with statement. Change B21... to B22...
# For your convenience, a copy of the task is given below, with updated numbers.

# Write "Hello World!" to the file "B22.info.txt"
# Open and print the contents of B22.info.txt