# B21: Files II

# However, we may also want to write to files.
# To do this, we can use the "a" and "w" paramaters, such as:
# file = open("example.txt", "w")

# This would open a file in a write state, which will cause us to override the data.
# In order to add to the data (append), we would use "a".
# Both "w" and "a" will CREATE a new file, if the file does not exist.#

# In order to actually write to a file, we need to use .write()
# The file will only be saved once we close the file with .close(), however.

# Write "Hello World!" to the file "B21.info.txt"
# Open and print the contents of B21.info.txt