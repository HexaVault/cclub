# B4: Types I

# Python variables can have different types.
# Each type has different properties.

# The int function allows us to convert from string to int
# Convert the below number into a string.

# IF you are stuck, think what 3 letter builtin, like int, would convert to a string

var = 7
# Replace this comment to change var into a string using a function