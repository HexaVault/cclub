# B18: Strings V

# We can even use negative numbers.
# Unlike positive numbers, these go from right to left, and start at -1

# This means in the string "abcdef", [-1] is f, [-2] is e, and [:-1] is abcde

# Take in a string from the user
# Print the last character in the string
# Print the string if you get rid of the first and last character.