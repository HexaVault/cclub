# B12: Numbers IV

# We can also get the remainder of a division, using the modulo operator..
# This operator is represented by the % symbol.

# For example, 22 % 6 = 4, since 22 / 6 = 3 remainder 4

# Write code that prints if number % 5 is equal to 2
# This code should replace the pass statement in the below for loop

for num in range(1, 50):
  pass