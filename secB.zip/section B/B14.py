# B14: Strings I

# We can actually manipulate strings to a big extent in python.
# For example, we can merge two strings together (concatenate) strings, using +.

# Take in 4 inputs from the user.
# Concatenate them together
# Print the concatenated string back to the user