# Week 2 - Variables and if statements

# Task 4: Modulo:

# The modulo operator, denoted by the % symbol, is an operator that acts as the remainder.
# Given a value n (i.e. 17), we can write it as ab + c (i.e. 3(5) + 2).
# This would mean that n % b (i.e. 17 % 5) is equal to c (2).
# Another way to think of it, is to think about taking away b till you get a number less than b.

# Use this information to do the following:
# Take an input from the user and run it through float(x)
# Print a statement if hte number is divisble by 2, 3, 5 or 7
# Print whether the number is an integer (whole number) or not.