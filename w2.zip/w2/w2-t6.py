from math import asin
arcsin = asin

# Week 2 - Variables and if statements

# Task 6: Areas of intersecting circles
# Allow pi to be 3.14 in this scenario

# The area of a circle can be given by pi * r * r, where pi is the constant starting 3.14
# If we have 2 circles that are the same size, we can find their total area fairly easily.
# If the distance between the two centres is greater than 2r, than the area is just 2 * pi * r^2
# If the distance is less then this, we need to find the area of the intersecting section (the "lens")
# We can do so by drawing a line in the middle of the lens, finding the area on one side of the lens, and doubling it.
# We will presume that the circles do not heavily overlap (i.e. The centre of each circle is not contained within the other circle)
# We can find this doing the following:
# Calculate the width of the lens via 2r - dist(c1, c2)
## We can calculate distance using sqrt(x^2 + y^2), where x and y is the difference in x and y for c1 and c2
# We can then halve this value to get a half lens, which we can call k.
# We can use (r-k)^2 + h^2 = r^2 to find h.
# We can then do 0.5r^2 * h/r to get the area of the triangle contained.
# We can also do 0.5r^2 * arcsin(h/r) - areaTriangle to get a piece of the lens, we will call L0
# 4L0 + 2hk = Area of Lens
# We can then do Area of circles (seperate) - Area of lens to get the area of the interesecting circles.

# Use this to find to take in inputs of 2 circles (x, y and radius of each circle, so 6 inputs)
# Find the area of the 2 circles combined.




















# Note: This is alot of writing, and it is meant to be challenging.
# It does not really do anything new, but if you are stuck move on to w3 and come back later.