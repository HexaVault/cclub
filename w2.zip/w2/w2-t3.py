# Week 2 - Variables and if statements

# Task 3: elif and else:

# If statements in python can be connected using elif and else.
# For example, you can have one line of code run if something is true, and another is false.
# You could do this using if-else, rather than "if x" and "if not x", and it is often faster.
# We can also use elif for shorthand for (if x, else (if x)), but it will be unused in this excersise.
# Repeat the last task, but print out whether the input is bigger or smaller for each nunber
# Numbers: 3, 7, 31, 127