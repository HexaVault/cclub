# Week 2 - Variables and if statements

# Task 2: Input comparison:

# We can use the lt (<), gt (>) or eq (==) comparison statements to compare values.
# For example, since 7 is bigger than 4, 7 > 4 will return true, and 7 < 4 will return false
# Use this info to do the following:

# Take an input from the user and convert it to a number
# Compare it to the numbers: 3, 7, 31, 127
# For each number, print out a statement if the input is bigger than that number