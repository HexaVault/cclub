# Week 2 - Variables and if statements

# Task 5: Boolean application:

# You may have tried at some point to print a statement, like a > 7 or 6 == 4, and seen it print out True or False
# These are called boolean values, and they can only have these 2 values (True or False).
# We can actually use a few different operators on boolean: not, or, and
# There is also xor, but it will not be used till much later down, as its use is much more uncommon.

# Use this info to do the following:
# Take an input from the user and convert it to a number
# Assume that this input is bounded between 2 and 21.
# Check whether the number is prime (You only need to check against 2, 3, 5 and 7)
# Check whether the number is not divisible by 5
# Check whether the number is smaller than 6 or bigger than 18