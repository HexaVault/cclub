# Week 2 - Variables and if statements

# Variables are the most powerful parts of programming, allowing us to store data for later use
# However, being able to effectively use variables can wildly affect how advantageous they are.
# Here, we are going to look at function operators.

# Task 1: Variable manipulation

myVar = 8
# We can manipulate variables in two ways:
# The first way is to do x = x <op> y, such as this:
myVar = myVar + 3
myVar = myVar * 3
# The second way is to do x <op>= y, such as this:
myVar /= 3
myVar -= 3
# This second way uses what we call ioperators, and is generally preferred when doing simple formulae like this

# Needed operator list: +, -, *, /, //, **, (, )

# Use this information to do the following:
# Assume myVar is an input, and is a number. Respond with the following info:
# x
# x add 2
# 2x
# (2x add 2) floordiv 7
# ((2x add 2) floordiv 5) to the powwer of 2

myVar = int(input("Input a Number: "))