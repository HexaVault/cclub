# Week 1 - I/O control and variables

# Task 2: Using special characters:

# As seen previously, we can print every character in a line individually.
# However, you might think it could be more efficient to print them all using one line.
# We can do this using the special character \n which stands for new line.
# Try using it to repeat the same task, but now use only 1 print function.

# List:
# Hello, World!
# Python
# Variables
# Print
# Test
