# Week 1 - I/O control and variables

# The print and input functions are among some of the most fundamental function for new programmers
# They allow the programmer rudimentary access to the terminal, to take inputs and outputs

# Task 1: Using the print function:

# Below is a set of strings to print. Some of the code has been written below.
# Add print statements to the below code to print the intended list.

# List:
# Hello World!
# Python
# Variables
# Print
# Test


print("Python")

print("Print")
print("Test")