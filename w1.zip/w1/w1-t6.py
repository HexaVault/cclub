# Week 1 - I/O control and variables

# Task 6: Input mayhem.

# Take in the following info from the user:
# Name
# Age
# Gender
# Height
# Job

# Push all this info into a single variable, splitting the info with newline characters
# Print the variable out to the user.
