# Week 1 - I/O control and variables

# Task 3: Taking an input

# So far, all we have done is printed what the user has said.
# However, we may want to take an input from the user, such as their name.
# We can use the below code to take an input from the user:

userInput = input("Input a string: ")

# Note that when we run this function, it will print the string, then halt until the user hits enter
# We can then use this input and print it, such as below:

print(userInput)

# Add an input to the below code, asking the user for a number between 1 and 10, and set the "chosenNumber" variable to their input.


if chosenNumber == "7":
  print("You guessed correctly")
else:
  print("You guessed incorrectly")