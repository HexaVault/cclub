# Week 1 - I/O control and variables

# Task 5: Variable modification

# Variables are the most powerful parts of programming, allowing us to store data for later use
# However, we can also use variables to clear up our code.
# Instead of concatenating inside the print function, we can concatenate to a variable, then print that function.
# An example can be seen below

myVar = "Hello"
myVar += " World!"
print(myVar)

# Use this information to do the following:

# Take the below for loop, and take an input from the user.
# Add \n followed by the users input to the variable.
# At the end of the while loop, print the stored text.

storedList = "List of items:"
userInput = # Take an input here
while userInput == "":
  #
  #
  userInput = # Take an input here
print()