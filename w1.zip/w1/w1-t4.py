# Week 1 - I/O control and variables

# Task 4: Concatenation

# So far we have taken an input from the user, but maybe we want to print it in a sentence.
# In order to print it in a sentence, we can use concatenation.
# This is simply pushing two strings together to make one.
# For example, the below code concatenates "Hello " and "World!" into "Hello World!" and prints it:
print("Hello " + "World!")

# Use this information to do the following:

# Ask the user for their name, and take an input
# Ask the user for their age by using their name, and take an input
# Tell the user "You are called <user> and are <age> years old."