# C4: Array IV

# We can also sort arrays, by using the .sort function.
# The .sort function is also powerful, as it allows us to define *how* to sort items.
# This requires defining a function however, so we won't look at it here.

# Sort the below array
array = [20601, 23597, 15162, 11149, 72821, 98951, 44331, 7504, 60562, 71864, 48348, 32879, 80434, 44951, 84732, 10657, 58077, 75959, 24391, 20284, 51114, 34430, 30605, 73523, 10052, 63864, 77323, 39897, 84670, 17529, 66939, 18313, 19887, 56807, 94130, 28449, 72154, 94853, 21645, 10349, 9260, 39331, 43090, 9927, 61859, 75351, 43108, 89681, 22601, 43730, 92529, 72300, 49492, 29750, 46688, 18897, 47484, 50235, 16637, 22905, 33044, 94290, 81319, 56525, 99876, 40292, 42676, 81177, 43838, 20045, 6277, 82038, 23116, 35461, 24150, 44181, 23102, 32549]
# Print out the smallest, second smallest and largest numbers
# (Remember, the list will be sorted smallest to biggest now)