import time
# C13: time I

# The time module allows us to get the current time of the computer
# This allows us to calculate info, such as the time it takes for something to run.
# To get the time, we can use the time function.
# This returns a named tuple (like a tuple dict mix)
# in the order: year, month, day, hour, min, sec, weekday, year day, dst, timezone, utcOffset

# We will only really be interested up to sec, maybe using weekday in some scenarios.
# Take the current computer date and print it to the user in the form dd/mm/yyyy