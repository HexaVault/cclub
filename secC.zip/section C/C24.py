import sys, os
# C24: sys I

# sys is our other dangerous module, allowing us to modify some values
# used by the very python interpreter itself.

# For example, it allows us to add new file paths to the list of paths checked when trying
# to import modules, allowing us to import modules from child and parent folders, alongside other locations.
# To do this, we append to the path.

# We can also increase the recursion limit, increasing the number of times a function (which we go through in section D)
# can call itself (recursion) before a RecursionError exception is thrown.
# This is done using the setrecursionlimit function

# We can also use os to get the current working directory (cwd) using cwd()

# Add the cwd to path
# Increase the recursion limit to 1550