# C20: try III

# Try blocks can also have else and finally
# Finally blocks will always run, regardless of returns, breaks or errors not caught by
# any except block (because they are only set for specific errors)
# We will rarely use finally blocks, but they are useful in cases
# where you might need to close a file regardless of if it worked

# The other part of try block is else
# This part will only run if the try part runs successfully, and is useful to ensure
# that you only have the parts that need to catch exception inside a try blocks, rather
# than all your code.

# Take an input from the user
# Try convert it to an int
# If it fails, set the value to 0
# If it succeeds, print that the conversion was successful
# Print the value using finally