# C1: Array I

# Arrays are the names for lists in programming.
# Unlike most programming language, python actually refers to these as lists, not arrays,
# however for consistency across languages we will refer to them as arrays anyways.

# An array is comma seperated, and is encased in [].

# Form 2 arrays. Array 1 should use [] and contain the values 1, 2, and 3
# Array 2 should use the list function, and contain the values a, b and c, as strings
