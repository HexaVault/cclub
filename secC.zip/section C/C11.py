import math
# C11: math III

# The math module also provides useful trignometric functions
# These functions are all in radians, so you will need to use radians(x) to convert
# degrees to radians. Calculate the below trig values, which are in degrees.
# sin 74
# cos 52
# tan 30
# tan 75
# cos 35
# cos 77
# sin 89
# tan 6