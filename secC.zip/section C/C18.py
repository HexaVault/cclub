# C18: try I

# The try keyword allows us to run code that we dont know will work.
# It allows us to define code to run if an error is raised.
# For example, trying to use int on a string without any numbers will raise a number
# If any statement in the try fails, the rest is skipped without running.

# Take in an input from the use
# Try convert it to an integer
# If it succeeds, print that the input converted successfully