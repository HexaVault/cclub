# C8: import I

# We can import code from other files and module using import
# This keyword generally is included at the top of files, however in
# this file we will use the statement in the middle.

# Import the math module
# Print the answer to ln(4+1) using log1p (1p does a +1 automatically)