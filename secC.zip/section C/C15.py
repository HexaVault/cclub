import re
# C15: re I

# The re module allows us to handle regex in python.
# We will look closer at regex in section E
# This module requires us to set a vcariable to a regex object, using re.compile(pattern),
# which we can then use in re.search(pattern, string)
# Alternatively, we can just put the pattern in re.search if we dont use many, as they are cached for speed.

# Find whether "d23y9fb239h2f34" matches the regex "[0-9]+y9[a-zA-z0-9]{5}..." at all or not.
# re.search will return a falsy value if it does not, else it will return a truthy value