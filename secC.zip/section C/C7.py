# C7: Set I

# Sets are unordered, unchangable items.
# Sets are useful however, since they do not allow duplicate values.
# This means we can use them effectively to remove duplicates (which may arise due to poor code)

# To create a set, we can either use {} (but not in key:value pairsa)
# or we can use the Set() builtin

# Create a set, using the below array
# Print the length of both the array and set using len()
array = [26, 23, 20, 2, 32, 9, 30, 39, 3, 20, 35, 25, 7, 48, 40, 27, 37, 32, 45, 4, 1, 46, 21, 6, 24, 10, 18, 47, 33, 31, 11, 20, 7, 23, 15, 47, 41, 13, 42, 1, 22, 46, 10, 0, 22, 8, 23, 43, 4, 38, 12, 11, 19, 13, 11, 0, 23, 17, 42, 17, 22, 29, 38, 26, 14, 27, 2, 15, 0, 2, 39, 48, 48, 3, 44, 11, 0, 5]
# (To unpack an array (eg if you want to pass each item into a function like set()),
# we can place a * before the array, which will unpack it)