import math
# C9: math I

# The math module contains lots of useful mathematical functions.
# To begin with, we will look at the constands, floor and ceil.

# The math module has 2 main constants:
# e, approx equal to 2.718281828...
# pi, approx equal to 3.141592653...

# Additionally, the math module contains lots of functions
# The ceil() function rounds a number to the next highest number
# The floor() function rounds a number down to the next lowest number

# Since we are importing, the entire math module, to use these constans and functions,
# we use dot notation (which we will go through alot more in section D)

# For the math module, we use math.<item>
# This means that floor will be math.floor(x), and pi will be math.pi

# Calculate the floor and ceil of pi and e