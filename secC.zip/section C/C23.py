import os
# C23: os I

# The os module is one of, if not the most dangerous module in python.
# Unlike other modules, it allows us to modify large parts of the internals of a computer,
# including user logins, file permissions (read, write, execute) and more, given sufficient permissions.

# We will mainly be using os for file paths, as well as file deletion.
# In order to remove a file, we can use the remove statement, followed by file name (and extension),
# similarly to if we were to open the file in read using open()

# Delete file C23.info.txt