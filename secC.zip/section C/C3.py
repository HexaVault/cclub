# C3: Array III

# Arrays also come with some other useful functions.
# For example, the .append function.

# Given a variable set to a variable, we can add one item to that array with .append
# This is a MUTABLE operation, meaning it changes the variable (we can just do x.append(y), not x = x.append(y))

# The alternate way to do this is a + b, where a and b are both arrays, and this will merge them together

# Below is an array
# Append the number 4 to it
# Print the array

array = [0, 1, 2, 3]