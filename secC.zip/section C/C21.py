import warnings
# C21: warnings I

# Warning are a useful way of altering a user about an issue, without raising an exception.
# This may be useful in cases where someone is using a depreceated function.

# In order to raise a warning, we use warn, with a message, and optional category.
# We can also state stack level and otherwise, but this is only relevant when we get to file hierarch (section E)

# Make a try-except-else-finally loop for int, like C20 (these instructions will be listed below)
# Raise a warning instead of printing a message if conversion failed

# C20 instructions:
# Take an input from the user
# Try convert it to an int
# If it fails, set the value to 0
# If it succeeds, print that the conversion was successful
# Print the value using finally