# C19: try II

# The try statement also allows us to run code if the statement fails using except
# For example, we might want to set a default value if a statement fails
# We can also specify certain errors in an except cause (i.e. except SyntaxError)

# Take an input from the user
# Try convert it to an int
# If it fails, set the value to 0
# Print the value