# C6: Dict I

# Dict, or dictionaries, allow us to define key:value pairs
# They are ordered and changable, but we cannot define duplicate keys.

# A key means that instead of using order (i.e. 0, 2, 6), we can use a key
# (i.e. a name) to access the data. Below is an example of a dict

exampleDict = {
  "itemA": 4,
  "itemB": "string",
  "itemC": {
    "another": "dict"
  },
  "itemD": [1, 2, 3]
}

# The values for each key can be labelled whatever, and unlike variable names, we
# can have spaces in key names. To access an item, we use dict["keyname"].

# Create a dict for a car
# It should contain: owner, car name, age, brand