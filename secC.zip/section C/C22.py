# C22: Errors I

# Similarly to warnings, you may want to manually raise an error
# This is especially prevalant with sections D and E, when inputs
# and outputs can vary and are very much unknown.

# To do so, we use the raise <error> statement
# In order to include a message, we add a ("message") after the <error>, without a space

# Make a try-except-else-finally loop for int, like C20 (these instructions will be listed below)
# Raise an error instead of printing a message if conversion failed

# C20 instructions:
# Take an input from the user
# Try convert it to an int
# If it fails, set the value to 0
# If it succeeds, print that the conversion was successful
# Print the value using finally