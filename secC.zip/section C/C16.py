import random
# C16: random I

# The random module allows us to get a lot of (deterministic) randomness.
# One example of this is randint
# This picks a random number betwen the start a and end b

# Make a loop that prints an incrementing number
# until a random number between 0 and 50 is equal to 45