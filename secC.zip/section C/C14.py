import time
# C14: time II

# The time module also allows us to tell the program to sleep for a certain amount of time
# You can guess what this function is called.
# Make 2 print statements, with a 3 second sleep inbetween