import math
# C10: math II

# Another set of useful functions provided by math are:
# GCD - Greatest common denominator
# LCM - Lowest common multiple

# Calculate the GCD of:
# 2, 7
# 48, 892
# 782, 927
# 271, 523

# Calculate the LCM of:
# 17, 21
# 82, 62
# 62, 71
# 90, 72