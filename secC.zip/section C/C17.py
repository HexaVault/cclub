import random
# C17: random II

# The random module also provides a choice function
# This functions picks a random item from a list (i.e. array)

# Print out a random item out of the below list:
array = ["cherry", "apple", "orange", "kiwi", "papaya", "dragonfruit", "grapefruit", "grape", "strawberry"]