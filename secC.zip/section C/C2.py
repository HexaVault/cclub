# C2: Array II

# Similarly to strings, we can also splice arrays
# All the [] techniques work on arrays, so we'll briefly list them here

# [a:] - Take from the ath item
# [:b] - Up to the bth item
# [::c] - Every cth item, from item 0 (first)
# [d] - Dth item
# + all negative variants

# Below is an array
array = [7, 14, "c", [1, 2], 5, "h", 8, 11, "c", -3, 44.72, 4 + 3, "ek" * 4, 7, ["a", "b", "c"]]

# Print out
# 4th item
# Last item
# Last 3 item
# First 4 items
# items 6-8
# The string backwards
# The last 3 items of the array, backwards
# Every second item
# Every second item, excluding the last 2