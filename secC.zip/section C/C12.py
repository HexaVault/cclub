import math
# C12: math IV

# math also contains calculations for integer square root and exp(x) (= e^x)
# Calculate the isqrt of the below values:

# floor(77.7)
# e^pi
# 712
# ceil(24.3)
# 9173 % 261