# C5: Tuple I

# Tuples work similarly to array, in that they store data in an ordered way.
# However, tuple are immutable, and so cannot be modified in any way.
# This means we cant add, remove or change items.
# We can however define new variable by joining tuples together with the + operator.
# We create tuples by using (), with items that are comma seperated

# Below are two tuples.
# Print them joined together as 1 tuple
tuple1 = (0, 2, 4, 6, 8)
tuple2 = (6, 4, 2, 0, -2)
