import math
# Week 3 - Flow control and Imports

# Task 4 - Δv and Δγ/a

# The lorentz factor shows us how much time slows down relative to the speed of an observer.
# This is calculated using γ = 1/sqrt(1 - v^2/c^2) where c is the speed of light, and v is the acceleration of the observer.
# We can calculate the change in this relative to the change in velocity, or Δv, such that we get
# a formula to calculate Δγ/Δv
# Finally, we know that Δv/Δt = a, and so we can calculate the change in lorentz factor (dilation) based on acceleration and time.

# Take an input of acceleration and time from the user, and use it to calculate Δγ and accleration.
# We can then use this to help us calculate Δv.

# Δv is the amount of change of velocity we have (how much we can accelerate/deccelerate).
# Given that we have Δγ, acceleration and time, we may also need to calculate Δv.

# Write a piece of code that takes aceeleration, time, and either Δγ or Δv, and returns the other value
