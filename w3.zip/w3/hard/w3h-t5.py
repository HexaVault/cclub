# Week 3 - Flow control and Imports

# Task 5 - Upgrade Trees:

# Take inputs from the user for items and how long it takes to get them.
# Once the user has oinput what they want, they should then input recipes.
# Recipes are in the form: "Item = Ax 'Item1', Bx 'Item2', Cx 'Item3', etc"
# Once the user has input all recipes, use the last item input to create an upgrade tree
# The tree should show each item broken down into its fundamental bits (listed at the start)
# And should also give a time estimate for each item (and the total, split for each individual item)