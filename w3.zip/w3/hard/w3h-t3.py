# Week 3 - Flow control and Imports

# Task 3 - Least Squares Regression line

# Given a set of data (x_i, y_i):
# n = number of data points
# Mx = sum(x) / n
# My = sum(y) / n
# Sxx = sum(x^2) - n * Mx^2
# Sxy = sum(x * y) - n * Mx * My
# Syy = sum(y^2) - n * My^2

# β = Sxy/Sxx
# α = My - β * Mx

# Least squares regression line of data:
# y = α + βx

# PMCC: Sxy/sqrt(Sxx * Syy)

# Take in number points till the user states to stop
# Use the data given to calculate the least squares regression line and PMCC.
# Print these out to the user