# Week 3 - Flow control and Imports

# Task 2 - Complex flow control handling

# The function int(x, y) takes in a string and converts it to a number, via base y.
# For this task, assume that any value can be input.
# Your value must take in a sum of inputs and return an output when asked.
# You must accept:
# Denary, as default
# Binary, when prefixed with 0b
# Octal, when prefixed with 0o
# Hexadecimal, when prefixed with 0h
# Trinary, when prefixed with 0t

# Your program must meet the following criteria:
# No more than 16 lines of code
# No more than 350 characters
# All variable names must be reasonable
# You are limited to 3 stacks (indents) in your code.