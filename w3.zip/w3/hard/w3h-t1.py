# Week 3 - Flow control and Imports

# Task 1 - Try

# The function int(x) takes in a string and converts it to a number.
# For this task, assume that the user MIGHT be malicious, and will not always put in a number.
# Make a program that:
# Loops, taking an input each time
# For every number the user inputs, add it to a total
# Output the total

# Additionally, you must follow the below requirements:
# The program must be fully functional if the user does not put a valid value in
# The program must not allow inputs greater than 1e6
# The program must warn the user if their input is disallowed.
# Allows the user to exit the loop and see the total