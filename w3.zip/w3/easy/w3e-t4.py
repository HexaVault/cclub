# Week 3 - Flow control and Imports

# Task 4: Match.

# Apart from if statements, we can also use match statements.
# This allows us to match the input to certain strings. Note python does not fall through match statements.
# Below is an example:

testCase = "word"
match testCase:
  case "admin" | "test" | "testing":
    testCase = "password123"
  case "password":
    print("Insecure password")
  case _:
    pass

# Use a match-case statement to check the input of a user.
# If the input is python command, print that the user has input a command
# else if the input is a number, print that the user has input a number
# else print out the user input