import math
# Week 3 - Flow control and Imports

# Task 5: math.py

# The math module is a very important module in python.
# It provdes us with lots of useful functions, such as trigonometric, number constants and exponentiation.
# We can use this to begin calculating more complex values.

# sin = O/H, cos = A/H, tan = O/A, A^2 + O^2 = H^2. Area = OA/2
# Calculate sin, cos and tan of a triangle, given the length of all 3 sides.]

sides = [
  float(input("Length of side 1: ")),
  float(input("Length of side 2: ")),
  float(input("Length of side 3: "))
]