# Week 3 - Flow control and Imports

# So far, we have looked at IO, variables and if statements.
# However, what if you wanted to loop over a piece of code multiple times?
# You may also want to seperate your code into multiple files.
# These are cases where flow control and imports come into play.

# Task 1 - While loop

# The function int(x) takes in a string (i.e. from input() ) and converts it to a number.
# For this task, assume that the user is NOT malicious, and *will* put in a number.
# Make a program that:
# Loops until the user puts a number below 0, by using while
# For every number the user inputs that isnt below 0, add it to a total
# Output the total