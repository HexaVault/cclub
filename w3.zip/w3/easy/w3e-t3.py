# Week 3 - Flow control and Imports

# Task 3: break and continue

# Sometimes, you just want a loop to continue indefinitely till something happens
# This could be a timer running out, or this could be waiting for a user to input a certain value
# One way we can do this is while not x, however this requires you to finish the loop before checking the criteria.
# This means you could meet the criteria, then stop meeting the criteria before you hit the while statement.
# To fix this, we can use break and continue.
# continue will skip the rest of the current iteration of the current loop, while break will skip the rest of the current loop, in its entirety.

# Using this information:
# Take in a username and "password" from the user
# If the username and password match, exit the while True loop
# Else repeat till they do match.

# For ease of developmebt, the username and password are defined below as "a" and "b", but they can be changed.
username = "a"
password = "b"

while True:
  pass # You may remove the pass and write your code in here