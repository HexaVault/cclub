# Week 3 - Flow control and Imports

# Task 2: For loop

# The for loop allows you to iterate through a list, one at a time.
# For each iteration, the variable listed is set to the item (often called value)
# Using this information, read the below section.

# The first part of this program has been done for you.
# Count each item in the array, and return:
# The number of items
# The sum of the array
# The biggest value via max()
# The smallest value via min()
# The mean value

listOfInputs = []

try:
  while True:
    listOfInputs.append(int(input("Type in a number: ")))
except:
  0 # This serves no purpose but to stop the code from breaking
